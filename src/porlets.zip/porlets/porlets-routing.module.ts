import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PorletsComponent } from './contenedor/porlets.component';
import { SearchShopComponent } from './components/search-shop/search-shop.component';
import { CitaPreviaComponent } from './components/cita-previa/cita-previa.component';

export const routes: Routes = [
  { path: '', component: PorletsComponent,
    children: [
      {
        path: '',
        component: SearchShopComponent,
      },
      {
        path: 'cita/:id',
        component: CitaPreviaComponent
      }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PorletsRoutingModule { }