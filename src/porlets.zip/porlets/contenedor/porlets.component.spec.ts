import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PorletsComponent } from './porlets.component';

describe('PorletsComponent', () => {
  let component: PorletsComponent;
  let fixture: ComponentFixture<PorletsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PorletsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PorletsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
