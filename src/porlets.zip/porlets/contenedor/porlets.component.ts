import { Component, OnInit } from '@angular/core';
import { TallerService } from '../../../core/services/talleres.service';
import { Taller } from '../interfaces/talleres.interface';


@Component({
  selector: 'app-porlets',
  templateUrl: './porlets.component.html',
  styleUrls: ['./porlets.component.scss']
})
export class PorletsComponent implements OnInit {

  public talleres: Taller[];
  public taller: Taller;
  public show: boolean;

  constructor( private tallerService: TallerService ) {
    this.show = true;
  }

  ngOnInit() {

    this.talleres = this.tallerService.getTalleres();
    
  }

  selectedTaller(event) {
    console.log('Parent ', event);
    this.show = !this.show;
    this.taller = event;
  }

}
