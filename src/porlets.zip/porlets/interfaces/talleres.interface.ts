export interface Taller {
    id: number;
    name: string;
    address: string;
    phone: string;
    postal: string;
    distance: number;
    // tipo_casa: string | null;
  }