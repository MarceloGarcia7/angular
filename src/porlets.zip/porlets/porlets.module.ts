import { NgModule } from '@angular/core';
// import { NxCoreModule } from '@allianz/core';
import { PorletsRoutingModule } from './porlets-routing.module';
import { AppSharedModule } from '../../shared/shared.module';
import { PorletsComponent } from './contenedor/porlets.component';
import { SearchShopComponent } from './components/search-shop/search-shop.component';
import { FilterPipe } from './pipe/filter.pipe';
// import { CommonModule } from '@angular/common';
import { CitaPreviaComponent } from './components/cita-previa/cita-previa.component';



@NgModule({
  imports: [
    // CommonModule,
    PorletsRoutingModule,
    // NxCoreModule,
    AppSharedModule
  ],
  declarations: [
    PorletsComponent,
    SearchShopComponent,
    CitaPreviaComponent,
    FilterPipe
  ],
})
export class PorletsModule { }